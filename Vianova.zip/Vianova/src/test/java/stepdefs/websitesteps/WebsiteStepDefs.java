package stepdefs.websitesteps;

import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.junit.Ignore;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import selenium.WebDriverFactory;
import stepdefs.CommonStepObjects;

public class WebsiteStepDefs extends CommonStepObjects {


    String pathf1 = "/Users/fatlum/Desktop/sample upload/test.pptx";
    String pathf2 = "/Users/fatlum/Desktop/sample upload/test.docx";
    String pathf3 = "/Users/fatlum/Desktop/sample upload/test.jpg";
    String allF = pathf1 + " \n " + pathf2 + " \n " + pathf3;

    @Given("^The precondition for the test - goes to website or logs in$")
    public void thePreconditionForTheTestGoesToWebsiteOrLogsIn() throws Throwable {
        if (driver == null) driver = WebDriverFactory.getInstance().getWebDriver();
        driver.navigate().to(System.getProperty("websiteUrl"));
        new WebDriverWait(driver, 20).until(ExpectedConditions.numberOfElementsToBeMoreThan(By.cssSelector("div"), 10));
        driver.findElement(By.id("username")).sendKeys("teacher");
        Thread.sleep(3000);
        driver.findElement(By.id("password")).sendKeys("]z&Y8Pyf");
        Thread.sleep(3000);
        driver.findElement(By.cssSelector("#kc-form-options > div > label")).click();
        Thread.sleep(3000);
        driver.findElement(By.id("kc-login")).click();
        Thread.sleep(5000);
        Thread.sleep(2000);
    }

    @And("^The next step that gets repeated before every test$")
    public void theNextStepThatGetsRepeatedBeforeEveryTest() throws Throwable {
    }

    @When("^The step that the test is created for is executed in the when step$")
    public void theStepThatTheTestIsCreatedForIsExecutedInTheWhenStep() throws Throwable {
    }

    @And("^The test continues$")
    public void theTestContinues() throws Throwable {
    }

    @And("^The test continues some more$")
    public void theTestContinuesSomeMore() throws Throwable {
    }

    @Then("^The assertion that the test has passed and worked fine$")
    public void theAssertionThatTheTestHasPassedAndWorkedFine() throws Throwable {
    }

//    @Ignore
//    @And("^The user will log in$")
//    public void theUserWillLogIn() throws InterruptedException {
//        driver.findElement(By.cssSelector("#kc-registration > span > a")).click();
//        Thread.sleep(3000);
//        driver.findElement(By.id("firstName")).sendKeys("testi12");
//        Thread.sleep(3000);
//        driver.findElement(By.id("lastName")).sendKeys("test3434");
//        Thread.sleep(3000);
//        driver.findElement(By.id("email")).sendKeys("test@gmail.com");
//        Thread.sleep(3000);
//        driver.findElement(By.id("password")).sendKeys("testi213123");
//        Thread.sleep(3000);
//        driver.findElement(By.id("password-confirm")).sendKeys("testi213213");
//        Thread.sleep(3000);
//        driver.findElement(By.cssSelector("#kc-form-options > div > span > a")).click();
//        Thread.sleep(3000);
//        driver.findElement(By.id("username")).sendKeys("teacher");
//        Thread.sleep(3000);
//        driver.findElement(By.id("password")).sendKeys("]z&Y8Pyf");
//        Thread.sleep(3000);
//        driver.findElement(By.cssSelector("#kc-form-options > div > label")).click();
//        Thread.sleep(3000);
//        driver.findElement(By.id("kc-login")).click();
//        Thread.sleep(5000);
//    }

    @And("^the user will go to basic page$")
    public void theUserWillGoToBasicPage() throws InterruptedException {
        driver.findElement(By.cssSelector("#mainWrapper > app-actibook-suite > section > div.container-fluid > div > div > div > div > div > div > div > div > button.animateMe.create-btn")).click();
        Thread.sleep(3000);
        driver.findElement(By.cssSelector("#mainWrapper > app-actibook-suite > section > div.popup-wrapper.openPopup > div.create-popup-holder > div > div.popup-tab-holder.create-tab.active > div.tab-content-wrapper > div:nth-child(1) > div.left-wrapper > input")).sendKeys("bleron");
        Thread.sleep(3000);
        driver.findElement(By.cssSelector("#mainWrapper > app-actibook-suite > section > div.popup-wrapper.openPopup > div.create-popup-holder > div > div.popup-tab-holder.create-tab.active > div.tab-content-wrapper > div:nth-child(2) > div.left-wrapper > input")).sendKeys("haskjfhasdjh");
        Thread.sleep(3000);
        driver.findElement(By.cssSelector("#mainWrapper > app-actibook-suite > section > div.popup-wrapper.openPopup > div.create-popup-holder > div > div.popup-tab-holder.create-tab.active > div.tab-content-wrapper > div:nth-child(3) > div.left-wrapper > input")).sendKeys("35");
        Thread.sleep(3000);
        driver.findElement(By.cssSelector("#masterdocumentleveldropdown")).click();
        Thread.sleep(3000);
        driver.findElement(By.cssSelector("#mainWrapper > app-actibook-suite > section > div.popup-wrapper.openPopup > div.create-popup-holder > div > div.popup-tab-holder.create-tab.active > div.tab-content-wrapper > div.tab-content-row-wrapper.tooltipShow > div.left-wrapper > div > div > a:nth-child(2)")).click();
        Thread.sleep(3000);
        driver.findElement(By.cssSelector("#mainWrapper > app-actibook-suite > section > div.popup-wrapper.openPopup > div.create-popup-holder > div > div.popup-tab-holder.create-tab.active > button")).click();
        Thread.sleep(3000);
        driver.findElement(By.cssSelector("#mainWrapper > app-actibook-suite > section > div.popup-wrapper.openPopup > div.create-popup-holder > div > div.popup-tab-holder.upload-tab.active.uploaded > div.tab-content-wrapper > div > ng2-file-input > div > input[type=\"file\"]")).sendKeys(allF);
        Thread.sleep(3000);
        driver.findElement(By.cssSelector("#mainWrapper > app-actibook-suite > section > div.popup-wrapper.openPopup > div.create-popup-holder > div > div.popup-tab-holder.upload-tab.active.uploaded > button.uploaded.nextStep")).click();
        Thread.sleep(3000);
        driver.findElement(By.cssSelector("#mainWrapper > app-actibook-suite > section > div.popup-wrapper.openPopup > div.create-popup-holder > div > div.popup-tab-holder.upload-tab.active.uploaded > button.uploaded.nextStep")).click();
        Thread.sleep(3000);

//        /Users/fatlum/Desktop/sample upload/pdf.pdf



    }

    @And("^the user will go to after upload$")
    public void theUserWillGoToAfterUpload() throws InterruptedException {
        driver.findElement(By.cssSelector("#mainWrapper > app-actibook-suite > section > div.popup-wrapper.openPopup > div.create-popup-holder > div > div.popup-tab-holder.finish-upload-tab.active > div.tab-content-wrapper > div > button.uploadNewBook")).click();
        Thread.sleep(3000);
        driver.findElement(By.cssSelector("#mainWrapper > app-master-doc > section > div > div > div > div > div > div.collapsed-wrapper.uploadContent.wrapper.search-results > div.navigate-box-btn > a")).click();
        Thread.sleep(3000);
        driver.findElement(By.cssSelector("#mainWrapper > app-master-doc > section > div > div > div > div > div > div.collapsed-wrapper.uploadContent.wrapper.search-results.hovered > div.collapsed-header-wrapper > div > span")).click();
    }

//    @And("^the user will go to upload file$")
//    public void theUserWillGoToUploadFile() throws InterruptedException {
////       driver.findElement(By.xpath("//*[@id=\"mainWrapper\"]/app-actibook-suite/section/div[1]/div[3]/div/div[2]/div[2]/div/label")).click();
//        Thread.sleep(3000);
//    }
}


